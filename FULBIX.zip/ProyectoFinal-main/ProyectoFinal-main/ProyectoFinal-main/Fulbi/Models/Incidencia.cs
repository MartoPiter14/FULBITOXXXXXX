﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class Incidencia
    {
        public int IdIncidencia { get; set; }
        public int IdTipoIncidencia { get; set; }
        public int IdJugador { get; set; }
        public int IdPartido { get; set; }

        public virtual Partido IdPartidoNavigation { get; set; } = null!;
        public virtual TipoIncidencia IdTipoIncidenciaNavigation { get; set; } = null!;
    }
}
