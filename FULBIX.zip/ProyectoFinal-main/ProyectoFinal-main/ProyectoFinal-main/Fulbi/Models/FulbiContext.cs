﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Fulbi.Models
{
    public partial class FulbiContext : DbContext
    {
        public FulbiContext()
        {
        }

        public FulbiContext(DbContextOptions<FulbiContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Equipo> Equipos { get; set; } = null!;
        public virtual DbSet<Fecha> Fechas { get; set; } = null!;
        public virtual DbSet<Incidencia> Incidencias { get; set; } = null!;
        public virtual DbSet<Jugadore> Jugadores { get; set; } = null!;
        public virtual DbSet<Partido> Partidos { get; set; } = null!;
        public virtual DbSet<TipoIncidencia> TipoIncidencias { get; set; } = null!;
        public virtual DbSet<TipoTorneo> TipoTorneos { get; set; } = null!;
        public virtual DbSet<Torneo> Torneos { get; set; } = null!;
        public virtual DbSet<Usuario> Usuarios { get; set; } = null!;

       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Equipo>(entity =>
            {
                entity.HasKey(e => e.IdEquipo)
                    .HasName("PK_nuevosEquipos");

                entity.Property(e => e.Nombre)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdTorneoNavigation)
                    .WithMany(p => p.Equipos)
                    .HasForeignKey(d => d.IdTorneo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Equipos_Torneos");
            });

            modelBuilder.Entity<Fecha>(entity =>
            {
                entity.HasKey(e => e.IdFecha);

                entity.Property(e => e.Nombre)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdTorneoNavigation)
                    .WithMany(p => p.Fechas)
                    .HasForeignKey(d => d.IdTorneo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Fechas_Torneos");
            });

            modelBuilder.Entity<Incidencia>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.IdIncidencia).ValueGeneratedOnAdd();

                entity.HasOne(d => d.IdPartidoNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.IdPartido)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Incidencias_Partidos");

                entity.HasOne(d => d.IdTipoIncidenciaNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.IdTipoIncidencia)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Incidencias_TipoIncidencias");
            });

            modelBuilder.Entity<Jugadore>(entity =>
            {
                entity.Property(e => e.Apellido)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FechaNacimiento).HasColumnType("date");

                entity.Property(e => e.Nombre)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdEquipoNavigation)
                    .WithMany(p => p.Jugadores)
                    .HasForeignKey(d => d.IdEquipo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Jugadores_Equipos");
            });

            modelBuilder.Entity<Partido>(entity =>
            {
                entity.Property(e => e.Fecha).HasColumnType("datetime");

                entity.HasOne(d => d.IdEquipo01Navigation)
                    .WithMany(p => p.PartidoIdEquipo01Navigations)
                    .HasForeignKey(d => d.IdEquipo01)
                    .HasConstraintName("FK_Partidos_Equipos");

                entity.HasOne(d => d.IdEquipo02Navigation)
                    .WithMany(p => p.PartidoIdEquipo02Navigations)
                    .HasForeignKey(d => d.IdEquipo02)
                    .HasConstraintName("FK_Partidos_Equipos1");

                entity.HasOne(d => d.IdFechaNavigation)
                    .WithMany(p => p.Partidos)
                    .HasForeignKey(d => d.IdFecha)
                    .HasConstraintName("FK_Partidos_Fechas");
            });

            modelBuilder.Entity<TipoIncidencia>(entity =>
            {
                entity.HasKey(e => e.IdTipoIncidencias);

                entity.Property(e => e.Nombre)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TipoTorneo>(entity =>
            {
                entity.HasKey(e => e.IdTipoTorneo)
                    .HasName("PK_tipoTorneo");

                entity.ToTable("TipoTorneo");

                entity.Property(e => e.Modalidad)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Torneo>(entity =>
            {
                entity.HasKey(e => e.IdTorneo);

                entity.Property(e => e.Nombre)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdTipoTorneoNavigation)
                    .WithMany(p => p.Torneos)
                    .HasForeignKey(d => d.IdTipoTorneo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Torneos_TipoTorneo");

                entity.HasOne(d => d.IdUsuarioNavigation)
                    .WithMany(p => p.Torneos)
                    .HasForeignKey(d => d.IdUsuario)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Torneos_Usuarios");
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.HasKey(e => e.IdUsuario);

                entity.Property(e => e.Email)
                    .HasMaxLength(320)
                    .IsUnicode(false);

                entity.Property(e => e.Nombre)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
