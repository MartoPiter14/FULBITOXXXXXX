﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class TipoIncidencia
    {
        public int IdTipoIncidencias { get; set; }
        public string Nombre { get; set; } = null!;
    }
}
